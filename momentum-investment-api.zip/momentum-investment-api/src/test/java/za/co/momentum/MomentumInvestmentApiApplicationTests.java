package za.co.momentum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MomentumInvestmentApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
