package za.co.momentum.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/investors")
public class InvestorController {

    private final InvestorRepository investorRepository;
    private final ProductRepository productRepository;

    // Constructor injection
    public InvestorController(InvestorRepository investorRepository, ProductRepository productRepository) {
        this.investorRepository = investorRepository;
        this.productRepository = productRepository;
    }

    // Retrieve investor information
    @GetMapping("/{id}")
    public Investor getInvestor(@PathVariable Long id) {
        return investorRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Investor not found"));
    }

    // Retrieve a list of products the investor has invested in
    @GetMapping("/{id}/products")
    public List<Product> getInvestorProducts(@PathVariable Long id) {
        Investor investor = investorRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Investor not found"));
        return investor.getProducts();
    }

    // Create a new withdrawal for a given product
    @PostMapping("/{id}/products/{productId}/withdrawals")
    public void createWithdrawal(@PathVariable Long id, @PathVariable Long productId, @RequestBody WithdrawalRequest request) {
        Investor investor = investorRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Investor not found"));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new NotFoundException("Product not found"));

        // Apply the required validations
        if (product.getType() == ProductType.RETIREMENT && !isInvestorEligibleForRetirement(investor)) {
            throw new ValidationException("Investor is not eligible for retirement withdrawal");
        }

        if (request.getAmount().compareTo(product.getBalance()) > 0) {
            throw new ValidationException("Withdrawal amount cannot be greater than the current balance");
        }

        BigDecimal maxWithdrawalAmount = product.getBalance().multiply(BigDecimal.valueOf(0.9));
        if (request.getAmount().compareTo(maxWithdrawalAmount) > 0) {
            throw new ValidationException("Withdrawal amount cannot exceed 90% of the current balance");
        }

        // Process the withdrawal and update the product balance
        BigDecimal newBalance = product.getBalance().subtract(request.getAmount());
        product.setBalance(newBalance);
        productRepository.save(product);
    }

    // Helper method to check if the investor is eligible for retirement withdrawal
    private boolean isInvestorEligibleForRetirement(Investor investor) {
        // Implement the logic to check the investor's age
        // You can use the java.time.LocalDate class to calculate the age based on the date of birth
        // For example:
        int age = LocalDate.now().getYear() - investor.getDateOfBirth().getYear();
        return age > 65;
    }
}
