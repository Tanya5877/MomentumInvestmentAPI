package za.co.momentum.entity;

public enum ProductType {
    RETIREMENT,
    SAVINGS
}
